﻿
using System;
namespace MODEL
{
    public class Gruppe
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Beschreibung { get; set; }
        public DateTime Erstellungsdatum { get; set; }
        public ICollection<User>? Mitglieder { get; set; }
    }
}

