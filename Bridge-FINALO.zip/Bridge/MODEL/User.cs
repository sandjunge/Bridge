﻿using System;
namespace MODEL
{
    public class User
    {
        public int Id { get; set; }
        public string Username { get; set; }
        public string Email { get; set; }
        public string Passwort { get; set; }
        public DateOnly Geburtsdatum { get; set; }
        public Status Status { get; set; }

        public ICollection<Aktivitaet>? Aktivitaeten { get; set; }
        public ICollection<Nachricht>? Nachrichten { get; set; }

        public int? GruppeId { get; set; }
        public Gruppe? Gruppe { get; set; }
        public Profil? Profil { get; set; }

        public User(string username, string email, string passwort, DateOnly geburtsdatum)
        {
            Username = username;
            Email = email;
            Passwort = passwort;
            Geburtsdatum = geburtsdatum;
            Status = Status.Offline; // Standardstatus setzen
        }

        public User() { }
    }

    public enum Status
    {
        Online,
        Offline,
        Away
    }
}
