﻿using System;
namespace MODEL
{
    public class AktivitaetDTO
    {
        public int Id { get; set; }
        public DateTime Login { get; set; }
        public DateTime Logoff { get; set; }
        public int UserId { get; set; }
        public string Username { get; set; }
    }
}

