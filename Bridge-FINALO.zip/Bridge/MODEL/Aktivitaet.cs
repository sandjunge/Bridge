﻿using System;
namespace MODEL
{
    public class Aktivitaet
    {
        public int Id { get; set; }
        public DateTime Login { get; set; }
        public DateTime Logoff { get; set; }
        public int UserId { get; set; }
        public User User { get; set; }
    }
}

