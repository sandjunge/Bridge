﻿using Bogus;
using System;
using MODEL;

public static class BogusDaten
{
    public static void SeedDaten(Connection context)
    {
        context.Database.EnsureCreated();

        // Lösche alle bestehenden Daten
        context.Users.RemoveRange(context.Users);
        context.Gruppen.RemoveRange(context.Gruppen);
        context.Aktivitaeten.RemoveRange(context.Aktivitaeten);
        context.Nachrichten.RemoveRange(context.Nachrichten);
        context.Profile.RemoveRange(context.Profile);
        context.SaveChanges();

        // Initialisiere Faker
        Randomizer.Seed = new Random(8675309);

        // Erstelle Gruppen
        var gruppenFaker = new Faker<Gruppe>()
            .RuleFor(g => g.Name, f => f.Commerce.Department())
            .RuleFor(g => g.Beschreibung, f => f.Lorem.Sentence())
            .RuleFor(g => g.Erstellungsdatum, f => f.Date.Past(1))
            .RuleFor(g => g.Mitglieder, f => new List<User>());

        var gruppen = gruppenFaker.Generate(2);
        context.Gruppen.AddRange(gruppen);
        context.SaveChanges();

        // Erstelle Benutzer und weise sie Gruppen zu
        var userFaker = new Faker<User>()
            .RuleFor(u => u.Username, f => f.Internet.UserName())
            .RuleFor(u => u.Email, f => f.Internet.Email())
            .RuleFor(u => u.Passwort, f => f.Internet.Password())
            .RuleFor(u => u.Geburtsdatum, f => DateOnly.FromDateTime(f.Date.Past(30, DateTime.Now.AddYears(-18))))
            .RuleFor(u => u.Status, f => f.PickRandom<Status>())
            .RuleFor(u => u.GruppeId, f => f.PickRandom(gruppen).Id);

        var users = userFaker.Generate(10);
        context.Users.AddRange(users);
        context.SaveChanges();

        // Erstelle Profile
        var profileFaker = new Faker<Profil>()
            .RuleFor(p => p.Bio, f => f.Lorem.Paragraph())
            .RuleFor(p => p.ProfilbildUrl, f => f.Internet.Avatar())
            .RuleFor(p => p.LinkedInProfil, f => f.Internet.UserName())
            .RuleFor(p => p.InstagramProfil, f => f.Internet.UserName())
            .RuleFor(p => p.YoutubeProfil, f => f.Internet.UserName())
            .RuleFor(p => p.LetztesUpdate, f => f.Date.Recent())
            .RuleFor(p => p.UserId, f => f.PickRandom(users).Id);

        var profiles = profileFaker.Generate(users.Count);
        context.Profile.AddRange(profiles);
        context.SaveChanges();

        // Erstelle Aktivitäten
        var aktivitaetenFaker = new Faker<Aktivitaet>()
            .RuleFor(a => a.Login, f => f.Date.Recent())
            .RuleFor(a => a.Logoff, f => f.Date.Soon())
            .RuleFor(a => a.UserId, f => f.PickRandom(users).Id);

        var aktivitaeten = aktivitaetenFaker.Generate(users.Count * 3);
        context.Aktivitaeten.AddRange(aktivitaeten);
        context.SaveChanges();

        // Erstelle Nachrichten
        var nachrichtenFaker = new Faker<Nachricht>()
            .RuleFor(n => n.Text, f => f.Lorem.Sentence())
            .RuleFor(n => n.Zeitpunkt, f => f.Date.Recent())
            .RuleFor(n => n.UserId, f => f.PickRandom(users).Id);

        var nachrichten = nachrichtenFaker.Generate(users.Count * 3);
        context.Nachrichten.AddRange(nachrichten);
        context.SaveChanges();
    }
}
