﻿using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MODEL;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProfilController : ControllerBase
    {
        private readonly Connection _context;

        public ProfilController(Connection context)
        {
            _context = context;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<ProfilDTO>>> GetProfile()
        {
            var profile = await _context.Profile
                .Include(p => p.User)
                .Select(p => new ProfilDTO
                {
                    Id = p.Id,
                    Bio = p.Bio,
                    ProfilbildUrl = p.ProfilbildUrl,
                    InstagramProfil = p.InstagramProfil,
                    LinkedInProfil = p.LinkedInProfil,
                    YoutubeProfil = p.YoutubeProfil,
                    LetztesUpdate = p.LetztesUpdate,
                    UserId = p.UserId,
                    Username = p.User.Username
                })
                .ToListAsync();

            if (profile == null || !profile.Any())
            {
                return NotFound();
            }

            return Ok(profile);
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<ProfilDTO>> GetProfil(int id)
        {
            var profil = await _context.Profile
                .Include(p => p.User)
                .Select(p => new ProfilDTO
                {
                    Id = p.Id,
                    Bio = p.Bio,
                    ProfilbildUrl = p.ProfilbildUrl,
                    InstagramProfil = p.InstagramProfil,
                    LinkedInProfil = p.LinkedInProfil,
                    YoutubeProfil = p.YoutubeProfil,
                    LetztesUpdate = p.LetztesUpdate,
                    UserId = p.UserId,
                    Username = p.User.Username
                })
                .FirstOrDefaultAsync(p => p.Id == id);

            if (profil == null)
            {
                return NotFound();
            }

            return Ok(profil);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateProfil(int id, ProfilDTO profilDto)
        {
            if (id != profilDto.Id)
            {
                return BadRequest();
            }

            var profil = await _context.Profile.FindAsync(id);
            if (profil == null)
            {
                return NotFound();
            }

            profil.Bio = profilDto.Bio;
            profil.ProfilbildUrl = profilDto.ProfilbildUrl;
            profil.InstagramProfil = profilDto.InstagramProfil;
            profil.LinkedInProfil = profilDto.LinkedInProfil;
            profil.YoutubeProfil = profilDto.YoutubeProfil;
            profil.LetztesUpdate = profilDto.LetztesUpdate;
            profil.UserId = profilDto.UserId;

            _context.Entry(profil).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!ProfilExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        private bool ProfilExists(int id)
        {
            return _context.Profile.Any(e => e.Id == id);
        }
    }
}
