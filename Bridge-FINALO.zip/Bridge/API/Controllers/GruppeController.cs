using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MODEL;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class GruppeController : ControllerBase
    {
        private readonly Connection _context;

        public GruppeController(Connection context)
        {
            _context = context;
        }

        // GET: api/Gruppe
        [HttpGet]
        public async Task<ActionResult<IEnumerable<GruppeDTO>>> GetGruppen()
        {
            var gruppen = await _context.Gruppen
                .Select(g => new GruppeDTO
                {
                    Id = g.Id,
                    Name = g.Name,
                    Beschreibung = g.Beschreibung,
                    Erstellungsdatum = g.Erstellungsdatum
                })
                .ToListAsync();

            return Ok(gruppen);
        }

        // GET: api/Gruppe/{id}
        [HttpGet("{id}")]
        public async Task<ActionResult<GruppeDTO>> GetGruppe(int id)
        {
            var gruppe = await _context.Gruppen
                .Select(g => new GruppeDTO
                {
                    Id = g.Id,
                    Name = g.Name,
                    Beschreibung = g.Beschreibung,
                    Erstellungsdatum = g.Erstellungsdatum
                })
                .FirstOrDefaultAsync(g => g.Id == id);

            if (gruppe == null)
            {
                return NotFound();
            }

            return Ok(gruppe);
        }

        // POST: api/Gruppe
        [HttpPost]
        public async Task<ActionResult<GruppeDTO>> AddGruppe(GruppeDTO gruppeDto)
        {
            var gruppe = new Gruppe
            {
                Name = gruppeDto.Name,
                Beschreibung = gruppeDto.Beschreibung,
                Erstellungsdatum = gruppeDto.Erstellungsdatum
            };

            _context.Gruppen.Add(gruppe);
            await _context.SaveChangesAsync();

            gruppeDto.Id = gruppe.Id;

            return CreatedAtAction(nameof(GetGruppe), new { id = gruppeDto.Id }, gruppeDto);
        }

        // PUT: api/Gruppe/{id}
        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateGruppe(int id, GruppeDTO gruppeDto)
        {
            if (id != gruppeDto.Id)
            {
                return BadRequest();
            }

            var gruppe = await _context.Gruppen.FindAsync(id);
            if (gruppe == null)
            {
                return NotFound();
            }

            gruppe.Name = gruppeDto.Name;
            gruppe.Beschreibung = gruppeDto.Beschreibung;
            gruppe.Erstellungsdatum = gruppeDto.Erstellungsdatum;

            _context.Entry(gruppe).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!GruppeExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // DELETE: api/Gruppe/{id}
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteGruppe(int id)
        {
            var gruppe = await _context.Gruppen.FindAsync(id);
            if (gruppe == null)
            {
                return NotFound();
            }

            _context.Gruppen.Remove(gruppe);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool GruppeExists(int id)
        {
            return _context.Gruppen.Any(e => e.Id == id);
        }
    }
}
