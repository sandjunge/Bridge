using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using MODEL;

namespace API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        private readonly Connection _context;

        public UserController(Connection context)
        {
            _context = context;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<UserDTO>>> GetUsers()
        {
            var users = await _context.Users
                .Include(u => u.Profil)
                .Include(u => u.Gruppe)
                .Include(u => u.Aktivitaeten)
                .Include(u => u.Nachrichten)
                .Select(u => new UserDTO
                {
                    Id = u.Id,
                    Username = u.Username,
                    Email = u.Email,
                    Passwort = u.Passwort,
                    Geburtsdatum = u.Geburtsdatum,
                    Status = u.Status,
                    GruppeId = u.GruppeId,
                    GruppeName = u.Gruppe != null ? u.Gruppe.Name : null,
                    Aktivitaeten = u.Aktivitaeten.Select(a => new AktivitaetDTO
                    {
                        Id = a.Id,
                        Login = a.Login,
                        Logoff = a.Logoff,
                        UserId = a.UserId,
                        Username = a.User.Username
                    }).ToList(),
                    Nachrichten = u.Nachrichten.Select(n => new NachrichtDTO
                    {
                        Id = n.Id,
                        Text = n.Text,
                        Zeitpunkt = n.Zeitpunkt,
                        UserId = n.UserId,
                        Username = n.User.Username
                    }).ToList(),
                    Profil = u.Profil != null ? new ProfilDTO
                    {
                        Id = u.Profil.Id,
                        Bio = u.Profil.Bio,
                        ProfilbildUrl = u.Profil.ProfilbildUrl,
                        InstagramProfil = u.Profil.InstagramProfil,
                        LinkedInProfil = u.Profil.LinkedInProfil,
                        YoutubeProfil = u.Profil.YoutubeProfil,
                        LetztesUpdate = u.Profil.LetztesUpdate,
                        UserId = u.Profil.UserId,
                        Username = u.Username
                    } : null
                })
                .ToListAsync();

            return Ok(users);
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<UserDTO>> GetUser(int id)
        {
            var user = await _context.Users
                .Include(u => u.Profil)
                .Include(u => u.Gruppe)
                .Include(u => u.Aktivitaeten)
                .Include(u => u.Nachrichten)
                .Select(u => new UserDTO
                {
                    Id = u.Id,
                    Username = u.Username,
                    Email = u.Email,
                    Passwort = u.Passwort,
                    Geburtsdatum = u.Geburtsdatum,
                    Status = u.Status,
                    GruppeId = u.GruppeId,
                    GruppeName = u.Gruppe != null ? u.Gruppe.Name : null,
                    Aktivitaeten = u.Aktivitaeten.Select(a => new AktivitaetDTO
                    {
                        Id = a.Id,
                        Login = a.Login,
                        Logoff = a.Logoff,
                        UserId = a.UserId,
                        Username = a.User.Username
                    }).ToList(),
                    Nachrichten = u.Nachrichten.Select(n => new NachrichtDTO
                    {
                        Id = n.Id,
                        Text = n.Text,
                        Zeitpunkt = n.Zeitpunkt,
                        UserId = n.UserId,
                        Username = n.User.Username
                    }).ToList(),
                    Profil = u.Profil != null ? new ProfilDTO
                    {
                        Id = u.Profil.Id,
                        Bio = u.Profil.Bio,
                        ProfilbildUrl = u.Profil.ProfilbildUrl,
                        InstagramProfil = u.Profil.InstagramProfil,
                        LinkedInProfil = u.Profil.LinkedInProfil,
                        YoutubeProfil = u.Profil.YoutubeProfil,
                        LetztesUpdate = u.Profil.LetztesUpdate,
                        UserId = u.Profil.UserId,
                        Username = u.Username
                    } : null
                })
                .SingleOrDefaultAsync(u => u.Id == id);

            if (user == null)
            {
                return NotFound();
            }

            return Ok(user);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateUser(int id, UserDTO userDto)
        {
            if (id != userDto.Id)
            {
                return BadRequest();
            }

            var user = await _context.Users.FindAsync(id);
            if (user == null)
            {
                return NotFound();
            }

            user.Username = userDto.Username;
            user.Email = userDto.Email;
            user.Geburtsdatum = userDto.Geburtsdatum;
            user.Status = userDto.Status;
            user.GruppeId = userDto.GruppeId;

            // Update the profile
            if (user.Profil != null)
            {
                user.Profil.Bio = userDto.Profil?.Bio;
                user.Profil.ProfilbildUrl = userDto.Profil?.ProfilbildUrl;
                user.Profil.InstagramProfil = userDto.Profil?.InstagramProfil;
                user.Profil.LinkedInProfil = userDto.Profil?.LinkedInProfil;
                user.Profil.YoutubeProfil = userDto.Profil?.YoutubeProfil;
                user.Profil.LetztesUpdate = userDto.Profil?.LetztesUpdate ?? default(DateTime); // Use default if null
            }

            _context.Entry(user).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!UserExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        [HttpPost]
        public async Task<ActionResult<UserDTO>> AddUser(UserDTO userDto)
        {
            try
            {
                if (userDto == null || string.IsNullOrEmpty(userDto.Username) || string.IsNullOrEmpty(userDto.Email) || userDto.Geburtsdatum == null)
                {
                    return BadRequest("Benötigte Benutzerdaten sind nicht vollständig.");
                }

                var user = new User(
                    userDto.Username,
                    userDto.Email,
                    userDto.Passwort,
                    userDto.Geburtsdatum
                );

                user.Status = userDto.Status;
                user.GruppeId = userDto.GruppeId;

                if (userDto.Profil != null)
                {
                    user.Profil = new Profil
                    {
                        Bio = userDto.Profil.Bio,
                        ProfilbildUrl = userDto.Profil.ProfilbildUrl,
                        InstagramProfil = userDto.Profil.InstagramProfil,
                        LinkedInProfil = userDto.Profil.LinkedInProfil,
                        YoutubeProfil = userDto.Profil.YoutubeProfil,
                        LetztesUpdate = userDto.Profil.LetztesUpdate
                    };
                }

                _context.Users.Add(user);
                await _context.SaveChangesAsync();

                userDto.Id = user.Id;
                if (user.Profil != null)
                {
                    userDto.Profil.Id = user.Profil.Id;
                }

                return CreatedAtAction(nameof(GetUser), new { id = user.Id }, userDto);
            }
            catch (DbUpdateException ex)
            {
                return BadRequest($"Datenbank-Fehler: {ex.InnerException?.Message ?? ex.Message}");
            }
            catch (Exception ex)
            {
                return BadRequest($"Allgemeiner Fehler: {ex.Message}");
            }
        }

        private bool UserExists(int id)
        {
            return _context.Users.Any(e => e.Id == id);
        }
    }
}
