﻿using Microsoft.AspNetCore.SignalR;
using System;
using System.Threading.Tasks;

namespace API.Hubs
{
    public class ChatHub : Hub
    {
        public async Task SendMessage(string user, string message)
        {
            try
            {
                await Clients.All.SendAsync("ReceiveMessage", user, message);
                Console.WriteLine($"Message sent: {user} - {message}");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Exception in SendMessage: {ex.Message}");
                throw;
            }
        }
    }
}
