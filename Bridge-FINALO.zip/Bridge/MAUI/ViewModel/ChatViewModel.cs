﻿using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using MAUI.Services;
using MODEL;
using System;
using System.Collections.ObjectModel;
using System.Threading.Tasks;

namespace MAUI.ViewModel
{
    public partial class ChatViewModel : ObservableObject
    {
        private readonly SignalRService _signalRService;

        [ObservableProperty]
        private string message;

        [ObservableProperty]
        private string username;

        public ObservableCollection<NachrichtDTO> Messages { get; } = new ObservableCollection<NachrichtDTO>();

        public ChatViewModel()
        {
            _signalRService = new SignalRService();
            _signalRService.MessageReceived += OnMessageReceived;

            try
            {
                _ = _signalRService.StartAsync();
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error starting SignalR service: {ex.Message}");
            }
        }

        private void OnMessageReceived(string user, string message)
        {
            Messages.Add(new NachrichtDTO { Username = user, Text = message, Zeitpunkt = DateTime.Now });
            Console.WriteLine($"Message received: {user} - {message}");
        }


        [RelayCommand]
        public async Task SendMessage()
        {
            try
            {
                await _signalRService.SendMessage(Username, Message);
                Message = string.Empty;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error sending message: {ex.Message}");
            }
        }

        public void Load()
        {

        }
    }
}
