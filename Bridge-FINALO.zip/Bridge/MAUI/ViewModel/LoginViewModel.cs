﻿using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using Microsoft.EntityFrameworkCore;
using MODEL;
using System.Linq;
using System.Threading.Tasks;

namespace MAUI.ViewModel;

public partial class LoginViewModel : ObservableObject
{
    [ObservableProperty]
    public string username;

    [ObservableProperty]
    public string passwort;

    [ObservableProperty]
    public string usernameEntryText = "Einloggen";
        
    public void Load()
    {
    }

    [RelayCommand]
    public async Task DatenChecker()
    {
        if (string.IsNullOrEmpty(Username) || string.IsNullOrEmpty(Passwort))
        {
            UsernameEntryText = "Login-Daten nicht vollständig";
            return;
        }

        using (var context = new Connection())
        {
            var user = await context.Users
                .FirstOrDefaultAsync(u => u.Username == Username && u.Passwort == Passwort);

            //hier check ich einfach ob er existiert oder nicht
            if (user is null)
            {
                UsernameEntryText = "Anmeldedaten richtig";
                await FensterWechselnChat();
            }
            else
            {
                UsernameEntryText = "Benutzername oder Passwort falsch";
            }
        }
    }

    [RelayCommand]
    public async Task FensterWechselnRegister()
    {
        await Shell.Current.GoToAsync("RegisterPage");
        Username = "";
        Passwort = "";
        UsernameEntryText = "Einloggen";
    }

    [RelayCommand]
    public async Task FensterWechselnChat()
    {
        await Shell.Current.GoToAsync("ChatPage");
    }
}
