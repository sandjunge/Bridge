﻿using MAUI.ViewModel;

namespace MAUI;

public partial class ChatPage : ContentPage
{
    private ChatViewModel _viewModel = new();

    public ChatPage()
    {
        InitializeComponent();
        BindingContext = _viewModel;
        Loaded += ChatPage_Loaded;
    }

    private void ChatPage_Loaded(object? sender, EventArgs e)
    {
        _viewModel.Load();
    }
}