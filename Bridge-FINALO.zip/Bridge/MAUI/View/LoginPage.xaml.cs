﻿using MAUI.ViewModel;

namespace MAUI;

public partial class LoginPage : ContentPage
{
    private LoginViewModel _viewModel = new();

    public LoginPage()
    {
        //mvvm verbindung mit anderen files aufbauen
        InitializeComponent();
        BindingContext = _viewModel;
        Loaded += LoginPage_Loaded;

        //hier mache das hintergrundbild zu dem discord background
        Image hintergrundbild = new Image
        {
            Source = "hintergrund.jpg",
            Aspect = Aspect.Fill
        };

        //Logingrid ist der Grid im XAML-File
        Grid.SetRowSpan(hintergrundbild, 3);
        Grid.SetColumnSpan(hintergrundbild, 3);
        LoginGrid.Children.Insert(0, hintergrundbild);
    }

    private void LoginPage_Loaded(object? sender, EventArgs e)
    {
        _viewModel.Load();
    }
}