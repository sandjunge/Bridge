﻿using Microsoft.EntityFrameworkCore;

namespace MODEL
{
    public class Connection : DbContext
    {
        public DbSet<User> Users { get; set; }
        public DbSet<Gruppe> Gruppen { get; set; }
        public DbSet<Aktivitaet> Aktivitaeten { get; set; }
        public DbSet<Nachricht> Nachrichten { get; set; }
        public DbSet<Profil> Profile { get; set; }

        public Connection(DbContextOptions<Connection> options) : base(options) { }

        public Connection() : base(new DbContextOptionsBuilder<Connection>().UseSqlite("Data Source=Database.db").Options) { }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                optionsBuilder.UseSqlite("Data Source=Database.db");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<Aktivitaet>()
                .HasOne(a => a.User)
                .WithMany(u => u.Aktivitaeten)
                .HasForeignKey(a => a.UserId)
                .OnDelete(DeleteBehavior.Cascade);

            modelBuilder.Entity<Nachricht>()
                .HasOne(n => n.User)
                .WithMany(u => u.Nachrichten)
                .HasForeignKey(n => n.UserId)
                .OnDelete(DeleteBehavior.Cascade);

            modelBuilder.Entity<User>()
                .HasOne(u => u.Gruppe)
                .WithMany(g => g.Mitglieder)
                .HasForeignKey(u => u.GruppeId)
                .OnDelete(DeleteBehavior.SetNull);

            modelBuilder.Entity<Profil>()
                .HasOne(p => p.User)
                .WithOne(u => u.Profil)
                .HasForeignKey<Profil>(p => p.UserId)
                .OnDelete(DeleteBehavior.Cascade);
        }
    }
}
