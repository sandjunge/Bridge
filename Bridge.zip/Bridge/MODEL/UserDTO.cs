﻿using System;
namespace MODEL
{
    public class UserDTO
    {
        public int Id { get; set; }
        public string Username { get; set; }
        public string Email { get; set; }
        public string Passwort { get; set; }
        public DateOnly Geburtsdatum { get; set; }
        public Status Status { get; set; }

        public int? GruppeId { get; set; }
        public string? GruppeName { get; set; }

        public List<AktivitaetDTO>? Aktivitaeten { get; set; }
        public List<NachrichtDTO>? Nachrichten { get; set; }
        public ProfilDTO? Profil { get; set; }
    }
}
