﻿using System;
namespace MODEL
{
	public class Profil
	{
        public int Id { get; set; }
        public string? Bio { get; set; }
        public string ProfilbildUrl { get; set; }
        public string? InstagramProfil { get; set; }
        public string? LinkedInProfil { get; set; }
        public string? YoutubeProfil { get; set; }
        public DateTime LetztesUpdate { get; set; }

        public int UserId { get; set; }
        public User User { get; set; }
    }
}

