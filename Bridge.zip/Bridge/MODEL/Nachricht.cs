﻿using System;
namespace MODEL
{
    public class Nachricht
    {
        public int Id { get; set; }
        public string Text { get; set; }
        public DateTime Zeitpunkt { get; set; }

        public int UserId { get; set; }
        public User User { get; set; }
    }
}

