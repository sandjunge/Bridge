﻿using System;
namespace MODEL
{
    public class GruppeDTO
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Beschreibung { get; set; }
        public DateTime Erstellungsdatum { get; set; }
    }
}

