﻿using MAUI.ViewModel;

namespace MAUI;

public partial class RegisterPage : ContentPage
{
    private RegisterViewModel _viewModel = new();

    public RegisterPage()
    {
        InitializeComponent();
        BindingContext = _viewModel;
        Loaded += RegisterPage_Loaded;

        //hier mache das hintergrundbild zu dem discord background
        Image hintergrundbild = new Image
        {
            Source = "hintergrund.jpg",
            Aspect = Aspect.Fill
        };

        //Logingrid ist der Grid im XAML-File
        Grid.SetRowSpan(hintergrundbild, 3);
        Grid.SetColumnSpan(hintergrundbild, 3);
        RegisterGrid.Children.Insert(0, hintergrundbild);
    }

    private void RegisterPage_Loaded(object? sender, EventArgs e)
    {
        _viewModel.Load();
    }
}
