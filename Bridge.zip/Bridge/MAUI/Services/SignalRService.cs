﻿using Microsoft.AspNetCore.SignalR.Client;
using System.Threading.Tasks;

namespace MAUI.Services
{
    public class SignalRService
    {
        private HubConnection _hubConnection;

        public async Task StartAsync()
        {
            _hubConnection = new HubConnectionBuilder()
                .WithUrl("https://localhost:7198/chathub") 
                .Build();

            _hubConnection.On<string, string>("ReceiveMessage", (user, message) =>
            {
                // Hier können Sie die empfangenen Nachrichten verarbeiten
                Console.WriteLine($"{user}: {message}");
            });

            await _hubConnection.StartAsync();
        }

        public async Task SendMessage(string user, string message)
        {
            await _hubConnection.InvokeAsync("SendMessage", user, message);
        }

        public async Task StopAsync()
        {
            await _hubConnection.StopAsync();
        }
    }
}
