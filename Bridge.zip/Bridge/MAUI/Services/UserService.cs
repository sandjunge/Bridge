﻿using MODEL;
using System.Net.Http.Json;
using System.Threading.Tasks;
using System.Diagnostics;

public class UserService
{
    private readonly HttpClient _httpClient;

    public UserService()
    {
        _httpClient = new HttpClient();
        _httpClient.BaseAddress = new Uri("https://localhost:7198");
    }

    public async Task<bool> RegisterUser(UserDTO user)
    {
        try
        {
            var response = await _httpClient.PostAsJsonAsync("api/user", user);
            response.EnsureSuccessStatusCode();
            return response.IsSuccessStatusCode;
        }
        catch (HttpRequestException httpEx)
        {
            Debug.WriteLine($"HTTP-Fehler: {httpEx.Message}");
            throw;
        }
        catch (Exception ex)
        {
            Debug.WriteLine($"Allgemeiner Fehler: {ex.Message}");
            throw;
        }
    }
}
