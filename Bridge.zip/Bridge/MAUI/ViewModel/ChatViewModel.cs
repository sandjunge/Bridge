﻿using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using MAUI.Services;
using System.Threading.Tasks;

namespace MAUI.ViewModel
{
    public partial class ChatViewModel : ObservableObject
    {
        private readonly SignalRService _signalRService;

        [ObservableProperty]
        private string message;

        [ObservableProperty]
        private string username;

        public ChatViewModel()
        {
            _signalRService = new SignalRService();
            _ = _signalRService.StartAsync();
        }

        [RelayCommand]
        public async Task SendMessage()
        {
            await _signalRService.SendMessage(Username, Message);
            Message = string.Empty;
        }

        public void Load()
        {

        }
    }
}
