﻿using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using MODEL;
using System.Threading.Tasks;

namespace MAUI.ViewModel
{
    public partial class RegisterViewModel : ObservableObject
    {
        private readonly UserService _userService;

        public RegisterViewModel()
        {
            _userService = new UserService();
            RegisText = "Registrieren";
        }

        [ObservableProperty]
        private string username;

        [ObservableProperty]
        private string email;

        [ObservableProperty]
        private string passwort;

        [ObservableProperty]
        private DateOnly geburtsdate;

        [ObservableProperty]
        private string regisText;

        [RelayCommand]
        public async Task FensterWechselnLogin()
        {
            await Shell.Current.GoToAsync("..");
            Email = "";
            Username = "";
            Passwort = "";
        }

        public void Load()
        {
            // Optionale Logik beim Laden der Seite
        }

        [RelayCommand]
        public async Task AccountErstellen()
        {
            try
            {
                var user = new UserDTO
                {
                    Username = this.Username,
                    Email = this.Email,
                    Passwort = this.Passwort,
                    Geburtsdatum = this.Geburtsdate,
                    Status = Status.Offline
                };

                var success = await _userService.RegisterUser(user);
                if (success)
                {
                    RegisText = "Registrierung erfolgreich.";
                    await Shell.Current.GoToAsync("..");
                }
                else
                {
                    RegisText = "Registrierung fehlgeschlagen.";
                }
            }
            catch (Exception ex)
            {
                RegisText = $"Fehler: {ex.Message}";
            }
        }
    }
}
