using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MODEL;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class NachrichtController : ControllerBase
    {
        private readonly Connection _context;
       
        public NachrichtController(Connection context)
        {
            _context = context;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<NachrichtDTO>>> GetNachrichten()
        {
            var nachrichten = await _context.Nachrichten
                .Include(n => n.User)
                .Select(n => new NachrichtDTO
                {
                    Id = n.Id,
                    Text = n.Text,
                    Zeitpunkt = n.Zeitpunkt,
                    UserId = n.UserId,
                    Username = n.User.Username
                })
                .ToListAsync();

            if (nachrichten == null || !nachrichten.Any())
            {
                return NotFound();
            }

            return Ok(nachrichten);
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<NachrichtDTO>> GetNachricht(int id)
        {
            var nachricht = await _context.Nachrichten
                .Include(n => n.User)
                .Select(n => new NachrichtDTO
                {
                    Id = n.Id,
                    Text = n.Text,
                    Zeitpunkt = n.Zeitpunkt,
                    UserId = n.UserId,
                    Username = n.User.Username
                })
                .FirstOrDefaultAsync(n => n.Id == id);

            if (nachricht == null)
            {
                return NotFound();
            }

            return Ok(nachricht);
        }
    }
}
