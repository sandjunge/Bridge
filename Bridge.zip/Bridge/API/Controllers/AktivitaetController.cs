using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MODEL;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AktivitaetController : ControllerBase
    {
        private readonly Connection _context;

        public AktivitaetController(Connection context)
        {
            _context = context;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<AktivitaetDTO>>> GetAktivitaeten()
        {
            var aktivitaeten = await _context.Aktivitaeten
                .Include(a => a.User)
                .Select(a => new AktivitaetDTO
                {
                    Id = a.Id,
                    Login = a.Login,
                    Logoff = a.Logoff,
                    UserId = a.UserId,
                    Username = a.User.Username
                })
                .ToListAsync();

            if (aktivitaeten == null || !aktivitaeten.Any())
            {
                return NotFound();
            }

            return Ok(aktivitaeten);
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<AktivitaetDTO>> GetAktivitaet(int id)
        {
            var aktivitaet = await _context.Aktivitaeten
                .Include(a => a.User)
                .Select(a => new AktivitaetDTO
                {
                    Id = a.Id,
                    Login = a.Login,
                    Logoff = a.Logoff,
                    UserId = a.UserId,
                    Username = a.User.Username
                })
                .FirstOrDefaultAsync(a => a.Id == id);

            if (aktivitaet == null)
            {
                return NotFound();
            }

            return Ok(aktivitaet);
        }
    }
}
